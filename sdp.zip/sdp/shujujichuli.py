from sklearn import model_selection
import pandas as pd

import pandas as pd
t="ant-1.3.csv"
odata = pd.read_csv(t)



x = odata['bug']



print(x)

data2 = pd.DataFrame(x)


data2.to_csv("antbiaoqian.csv")
