import random
from sklearn.neighbors import NearestNeighbors
import numpy as np
import pandas as pd
from sklearn import model_selection
class Smote:
    def __init__(self,samples,N=10,k=5):
        self.n_samples,self.n_attrs=samples.shape
        self.N=N
        self.k=k
        self.samples=samples
        self.newindex=0
        #self.synthetic=np.zeros((self.n_samples*N,self.n_attrs))

    def over_sampling(self):
        N=int(self.N/100)
        self.synthetic = np.zeros((self.n_samples * N, self.n_attrs))
        neighbors=NearestNeighbors(n_neighbors=self.k).fit(self.samples)
        print('neighbors',neighbors)
        for i in range(len(self.samples)):
            nnarray=neighbors.kneighbors(self.samples[i].reshape(1,-1),return_distance=False)[0]
            #print nnarray
            self._populate(N,i,nnarray)
        return self.synthetic


    # for each minority class samples,choose N of the k nearest neighbors and generate N synthetic samples.
    def _populate(self,N,i,nnarray):
        for j in range(N):
            nn=random.randint(0,self.k-1)
            dif=self.samples[nnarray[nn]]-self.samples[i]
            gap=random.random()
            self.synthetic[self.newindex]=self.samples[i]+gap*dif
            self.newindex+=1
t="data.csv"




with open(t) as f:

    data1 = np.loadtxt(f,str,delimiter = ",",skiprows=1,usecols=(0,1,2,3,4,5,6,7))

a=np.array(data1, dtype='float_')
s=Smote(a,N=100)
y=s.over_sampling()



import pandas as pd
f= pd.DataFrame(y)
'''f.to_csv('data1.csv')'''

