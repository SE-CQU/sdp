

# code by chenchiwei
# -*- coding: UTF-8 -*-
import numpy as np
from sklearn import tree
from time import *
import numpy as np
from sklearn import tree
from sklearn.naive_bayes import GaussianNB
# H 测试样本分类结果
# TrainS 原训练样本 np数组
# TrainA 辅助训练样本
# LabelS 原训练样本标签
# LabelA 辅助训练样本标签
# Test  测试样本
# N 迭代次数
def tradaboost(trans_S, trans_A1, label_S, label_A1, test,trans_A2,label_A2,trans_A3,label_A3,trans_A4,label_A4, N,test_label):
    trans_data1 = np.concatenate((trans_A1, trans_S), axis=0)
    trans_label1 = np.concatenate((label_A1, label_S), axis=0)
    trans_data2 = np.concatenate((trans_A2, trans_S), axis=0)
    trans_label2 = np.concatenate((label_A2, label_S), axis=0)
    trans_data3 = np.concatenate((trans_A3, trans_S), axis=0)
    trans_label3 = np.concatenate((label_A3, label_S), axis=0)
    trans_data4 = np.concatenate((trans_A4, trans_S), axis=0)
    trans_label4 = np.concatenate((label_A4, label_S), axis=0)
    trans_data = (trans_data1, trans_data2,trans_data3,trans_data4)
    trans_label=(trans_label1,trans_label2,trans_label3,trans_label4 )
    row_A1 = trans_A1.shape[0]
    row_A2 = trans_A2.shape[0]
    row_A3 = trans_A3.shape[0]
    row_A4 = trans_A4.shape[0]
    row_A=(row_A1,row_A2,row_A3,row_A4)
    row_S = trans_S.shape[0]
    row_T = test.shape[0]

    test_data1 = np.concatenate((trans_data[0], test), axis=0)
    test_data2 = np.concatenate((trans_data[1], test), axis=0)
    test_data3 = np.concatenate((trans_data[2], test), axis=0)
    test_data4 = np.concatenate((trans_data[3], test), axis=0)
    test_data=(test_data1,test_data2,test_data3,test_data4)

    # 初始化权重
    weights_A1 = np.ones([row_A1, 1]) / row_A1
    weights_A2 = np.ones([row_A2, 1]) / row_A2
    weights_A3 = np.ones([row_A3, 1]) / row_A3
    weights_A4 = np.ones([row_A4, 1]) / row_A4
    weights_A=(weights_A1,weights_A2,weights_A3,weights_A4)
    weights_S = np.ones([row_S, 1]) / row_S
    weights1 = np.concatenate((weights_A1, weights_S), axis=0)
    weights2 = np.concatenate((weights_A2, weights_S), axis=0)
    weights3 = np.concatenate((weights_A3, weights_S), axis=0)
    weights4 = np.concatenate((weights_A4, weights_S), axis=0)
    weights=(weights1,weights2,weights3,weights4)

    bata1 = 1 / (1 + np.sqrt(2 * np.log(row_A1 / N)))
    bata2 = 1 / (1 + np.sqrt(2 * np.log(row_A2 / N)))
    bata3 = 1 / (1 + np.sqrt(2 * np.log(row_A3 / N)))
    bata4 = 1 / (1 + np.sqrt(2 * np.log(row_A4 / N)))
    bata=(bata1,bata2,bata3,bata4)

    # 存储每次迭代的标签和bata值？
    bata_T = np.zeros([1, N])
    result_label1 = np.ones([row_A1 + row_S + row_T, N])
    result_label2 = np.ones([row_A2 + row_S + row_T, N])
    result_label3 = np.ones([row_A3 + row_S + row_T, N])
    result_label4 = np.ones([row_A4 + row_S + row_T, N])
    result_label=(result_label1,result_label2,result_label3,result_label4)
    predict = np.zeros([row_T])

    print ('params initial finished.')
    trans_data = np.asarray(trans_data, order='C')
    trans_label = np.asarray(trans_label, order='C')
    test_data = np.asarray(test_data, order='C')

    for i in range(N):
        P1 = calculate_P(weights1, trans_label1)
        P2=calculate_P(weights2, trans_label2)
        P3 = calculate_P(weights3, trans_label3)
        P4 = calculate_P(weights4, trans_label4)
        P=(P1,P2,P3,P4)
        for k in range(4):
             result_label[k][:, i] = train_classify(trans_data[k], trans_label[k],
                                            test_data[k], P[k])
             print ('result,', result_label[k][:, i], row_A[k], row_S, i,k, result_label[k].shape)

             error_rate= calculate_error_rate(label_S, result_label[k][row_A[k]:row_A[k] + row_S, i],
                                          weights[k][row_A[k]:row_A[k] + row_S, :])
             print('Error rate:', error_rate)
             if error_rate> 0.5:
                 error_rate = 0.5
             if error_rate == 0:
                 error_rate=0.000001
            # error_rate = 0.001
             list=[]
             list.append(error_rate)
        error_rate=min(list)
        index = list.index(min(list))
        print(error_rate)
        bata_T[0, i] = error_rate/(1-error_rate )

        # 调整源域样本权重

        for j in range(row_S):
            weights[index][row_A[index] + j] = weights[index][row_A[index] + j] * np.power(bata_T[0, i],
                                                               (-np.abs(result_label[index][row_A[index] + j, i] - label_S[j])))

        # 调整辅域样本权重
        for j in range(row_A[index]):
            weights[index][j] = weights[index][j] * np.power(bata[index], np.abs(result_label[index][j, i] - label_A1[j]))

    # print bata_T
    for j in range(4):
        for i in range(row_T):
        # 跳过训练数据的标签
            left = np.sum(
               result_label[j][row_A[j] + row_S + i, int(np.ceil(N / 2)):N] * np.log(1 / bata_T[0, int(np.ceil(N / 2)):N]))
            right = 0.5 * np.sum(np.log(1 / bata_T[0, int(np.ceil(N / 2)):N]))

            if left >= right:
               predict[i] = 1
            else:
               predict[i] = 0
            # print left, right, predict[i]

    p = test_label

    e3 = abs(p - predict)
    accuracy3 = 1 - sum(e3) / p.shape[0]


    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, cohen_kappa_score, \
        roc_auc_score
    from sklearn.metrics import roc_curve

    o = roc_auc_score(p, predict)
    print(o)

    r = f1_score(p, predict)


    TP = np.sum(np.logical_and(np.equal(p, 1), np.equal(predict, 1)))
      # false positive
    FP = np.sum(np.logical_and(np.equal(p, 0), np.equal(predict, 1)))
     # true negative
    TN = np.sum(np.logical_and(np.equal(p, 1), np.equal(predict, 0)))
     # false negative
    FN = np.sum(np.logical_and(np.equal(p, 0), np.equal(predict, 0)))

    pf= FP/ (TN + FP)

    pd=TP/(TP+FN)
    r1 = recall_score(p, predict, average='binary')


    a = 2 * r1 * (1 - pf)
    b = r1 + (1-pf)
    print(a / b)

def calculate_P(weights, label):
    total = np.sum(weights)
    return np.asarray(weights / total, order='C')


def train_classify(trans_data, trans_label, test_data, P):
    clf = tree.DecisionTreeClassifier(criterion="gini", max_features="log2", splitter="random")

    clf.fit(trans_data, trans_label, sample_weight=P[:, 0])
    return clf.predict(test_data)


def calculate_error_rate(label_R, label_H, weight):
    total = np.sum(weight)

    print(weight[:, 0] / total)
    print (np.abs(label_R - label_H))
    return np.sum(weight[:, 0] / total * np.abs(label_R - label_H))
def main():

     begin_time = time()
     p = "14.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(2, 3, 4, 5, 6, 7, 8,9,10,11,12,13,14,15,16,17,18,19,20,21))

     trans_A1 = np.array(data1, dtype='float_')

     p = "144.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))

     label_A1 = np.array(data1, dtype='float_')

     p = "21.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                            usecols=(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21))

     trans_A2 = np.array(data1, dtype='float_')

     p = "211.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(2))

     label_A2 = np.array(data1, dtype='float_')
     p = "02.csv"



     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                            usecols=(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21))

     trans_A3 = np.array(data1, dtype='float_')

     p = "022.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(2))

     label_A3 = np.array(data1, dtype='float_')
     p = "34.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                            usecols=(1,2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20))

     trans_A4 = np.array(data1, dtype='float_')

     p = "344.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(2))

     label_A4 = np.array(data1, dtype='float_')

     p = "ML11.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                            usecols=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20))

     X = np.array(data1, dtype='float_')
     p = "MLbiaoqian.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))
     Y = np.array(data1, dtype='float_')
     from sklearn.model_selection import train_test_split
     trans_S, test, label_S, test_label = train_test_split(

         X, Y, test_size=0.50, random_state=40)
     tradaboost(trans_S, trans_A1, label_S, label_A1, test, trans_A2, label_A2, trans_A3, label_A3, trans_A4, label_A4,
                50, test_label)
     '''
     p = "JM465.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1, 2, 3, 4, 5, 6, 7, 8))

     trans_A1 = np.array(data1, dtype='float_')

     p = "J4.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))

     label_A1 = np.array(data1, dtype='float_')
     p = "KC445.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1, 2, 3, 4, 5, 6, 7, 8))

     trans_A2 = np.array(data1, dtype='float_')

     p = "K1.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))
     label_A2 = np.array(data1, dtype='float_')
     p = "PC465.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1, 2, 3, 4, 5, 6, 7, 8))

     trans_S = np.array(data1, dtype='float_')
     p = "P4.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))

     label_S = np.array(data1, dtype='float_')

     p = "MC465.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1, 2, 3, 4, 5, 6, 7, 8))

     test = np.array(data1, dtype='float_')
     p = "M4.csv"

     with open(p) as f:
         data1 = np.loadtxt(f, str, delimiter=",", skiprows=1, usecols=(1))

     test_label= np.array(data1, dtype='float_')
     '''
     tradaboost(trans_S, trans_A1, label_S, label_A1, test, trans_A2, label_A2, trans_A3, label_A3, trans_A4, label_A4,
                50, test_label)
     end_time = time()
     run_time = end_time - begin_time
     print('该循环程序运行时间：', run_time)




if __name__ == '__main__':
    main()# @Software : PyCharm