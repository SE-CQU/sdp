# -*- coding: utf-8 -*-
# @Time     : 2019/7/1 13:53
# @Author   : Span
# @Site     : 
# @File     : processing.py
# @Function : Purpose of this script
# @Software : PyCharm
import pandas as pd
import numpy as np
data=pd.read_csv("cm1.csv")
data.Defective=data.Defective.map({'N':0,'Y':1})
data.head()
data.to_csv('cm11.csv')
