# -*- coding: utf-8 -*-
# @Time     : 2019/7/1 14:01
# @Author   : Span
# @Site     :
# @File     : z-score.py
# @Function : Purpose of this script
# @Software :
from sklearn import preprocessing
import pandas as pd
import numpy as np
data=pd.read_csv("PC311.csv")

my_matrix = np.loadtxt(open("PC311.csv","rb"),delimiter=",",skiprows=1)

X_scaled = preprocessing.scale(my_matrix)
d = pd.DataFrame(X_scaled)
d.to_csv('PC3111.csv')

