# python3
# -*- coding: utf-8 -*-
# @Author  : lina
# @Time    : 2018/11/23 13:05
"""
Autoencoder with single hidden layer.
"""
import numpy as np

from keras.datasets import mnist
from keras.models import Model
from keras.layers import Dense, Input
import matplotlib.pyplot as plt

np.random.seed(33)   # random seed，to reproduce results.

ENCODING_DIM_INPUT = 20
ENCODING_DIM_OUTPUT = 8
EPOCHS = 300
BATCH_SIZE = 100

def L2_loss(y_true, y_pre):
    return np.sum(np.square(y_true - y_pre))
def train(x_train):
    """
    build autoencoder.
    :param x_train:  the train data
    :return: encoder and decoder
    """
    # input placeholder
    input_image = Input(shape=(ENCODING_DIM_INPUT, ))

    # encoding layer
    hidden_layer = Dense(ENCODING_DIM_OUTPUT, activation='relu')(input_image)
    # decoding layer
    decode_output = Dense(ENCODING_DIM_INPUT, activation='relu')(hidden_layer)

    # build autoencoder, encoder, decoder
    autoencoder = Model(inputs=input_image, outputs=decode_output)
    encoder = Model(inputs=input_image, outputs=hidden_layer)

    # compile autoencoder
    autoencoder.compile(optimizer='adam', loss='mse')

    # training
    autoencoder.fit(x_train, x_train, epochs=EPOCHS, batch_size=BATCH_SIZE, shuffle=True)

    return encoder, autoencoder

def plot_representation(encode_images, y_test):
    """
    plot the hidden result.
    :param encode_images: the images after encoding
    :param y_test: the label.
    :return:
    """
    # test and plot
    plt.scatter(encode_images[:, 0], encode_images[:, 1], c=y_test, s=3)
    plt.colorbar()
    plt.show()

def show_images(decode_images, x_test):
    """
    plot the images.
    :param decode_images: the images after decoding
    :param x_test: testing data
    :return:
    """
    n = 10
    plt.figure(figsize=(20, 4))
    for i in range(n):
        ax = plt.subplot(2, n, i+1)
        ax.imshow(x_test[i].reshape(28, 28))
        plt.gray()
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)

        ax = plt.subplot(2, n, i + 1 + n)
        ax.imshow(decode_images[i].reshape(28, 28))
        plt.gray()
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)
    plt.show()


if __name__ == '__main__':
    # Step1： load data  x_train: (60000, 28, 28), y_train: (60000,) x_test: (10000, 28, 28), y_test: (10000,)

    import numpy as np
    import pandas as pd
    p = "CM111.csv"

    with open(p) as f:
        data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                           usecols=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20))

    a = np.array(data1, dtype='float_')

    # Step2: normalize
    x_train = a
    p = "EQ11.csv"

    with open(p) as f:
        data1 = np.loadtxt(f, str, delimiter=",", skiprows=1,
                           usecols=(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20))

    b= np.array(data1, dtype='float_')
    x_test=b
    # Step2: normalize


    # Step3: reshape data, x_train: (60000, 784), x_test: (10000, 784), one row denotes one sample.
    x_train = x_train.reshape((x_train.shape[0], -1))
    encoder, autoencoder= train(x_train=x_train)
    encode_images = encoder.predict(x_test)

    import pandas as pd
    # show images
    decode_images = autoencoder.predict(x_test)
    b=[]
    c=[]
    for i in range(x_test.shape[0]):
        b.append(L2_loss(x_test[i], decode_images[i]))
    # Step4： train
    df = pd.read_csv('ca11.csv', header=None)
    for i in range(x_test.shape[0]):
        if b[i]<10:
            c.append(i)



    import csv
    '''
    filename = 'ca11.csv'
    d=[]
    with open(filename, 'r', encoding='utf-8')as f:
        read = f.readlines()
        for index, info in enumerate(read):
            for i in range(len(c)):
                if index-1==c[i]:  # 这里判断

                   d.append(info)

   '''


    data1 = pd.DataFrame(b)

    data1.to_csv('III.csv')
'''
    filename = 'camel-1.0.csv'
    d = []
    with open(filename, 'r', encoding='utf-8')as f:
        read = f.readlines()
        for index, info in enumerate(read):
            for i in range(len(c)):
                if index == c[i]:  # 这里判断

                    d.append(info)
    
   
   data1 = pd.DataFrame(d)

    data1.to_csv('c4.csv')'''









